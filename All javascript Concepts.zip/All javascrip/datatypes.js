// D A T A  T Y P E S

        // console.log(typeof(name));
        // console.log(typeof(rollno));
        // console.log(typeof(age));
        // console.log(typeof(student));
        // console.log(typeof(student['isPass']));