// L O O P S   A N D   S T R I N G S

    //For Loop

        // for(let i=1;i<=10;i++)
        // {
        //     console.log(i*2);
        // }

        // let length=0;
        // for(let i=0;i<=100;i++)
        // {
        //     if(i%2===0)
        //     {
        //         console.log(i);
        //         length++;
        //     }
        // }
        // console.log("length is :",length);


    // while loop

        // let i=1;
        // while(i<=5)
        // {
        //     console.log("i : ",i);
        //     i++;
        // }

        // let guessNumber=1008;
        // let userNumber=prompt("Guess the number : ");
        // while(guessNumber!=userNumber){
        //     userNumber=prompt("you enterd wrong number. guess again :");
        // }
        // console.log("congrates you enterd right number");


    // do while loop

        // do {
        //     console.log(i*10);
        //     i++;
        // } while (i<=10);

    // for of loop    // basically use to srtings and arrays

        // let str="sandesh dadibude";
        // for (const val of str) {
        //     console.log("val : ",val);
        // }

    // for in loop   // use to object

        // let student={
        //     name : "sandesh dadinude",
        //     age : 19,
        //     rollNo : 104,
        //     isPass : true
        // };

        // for (const key in student) {
        //      console.log("key:",key ," value:", student[key]);
        // }
        


// S T R I N G

        // let name='sandesh';
        // console.log(name.length);
        // console.log(name[1]);

    // template literals 

        // let product={
        //     item:'laptop',
        //     price:20000,
        //     brand:'HP'
        // };
        // let output=`the cost of ${product.brand} ${product.item} is ${product.price} `;
        // console.log(output);


    //string methods

        // let str=" hii,i am sandesh ";
        // console.log(str.toUpperCase());
        // console.log(str.toLocaleLowerCase());
        // console.log(str.slice(5,17));
        // console.log(str.replace('sandesh','sandy'));
        // console.log(str.charAt(2));
        // console.log(str.concat('sandesh',28));


    