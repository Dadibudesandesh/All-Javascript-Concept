// C O N D I T I O N A L    S T A T M E N T


        // If statement

            // let mode="white";
            // console.log("mode : "+ mode);
            // if(mode=="white"){
            //     console.log("mode is light");
            // }
            
        // If else statement

            // let no=22;
            // console.log("No : ",no)
            // if(no%2==0){
            //     console.log("No is even");
            // }else{
            //     console.log("No is odd");
            // }


            // let num=prompt("Enter a number : ");
            // if(num%5===0){
            //     console.log(num,"is a multiple of 5");
            // }
            // else{
            //     console.log(num,"is a not multiple of 5");
            // }

        // Else if lader

            // let marks=89;
            // if(marks>90){
            //     console.log("Class A");
            // }else if(marks>=80){
            //     console.log("Class B");
            // }else{
            //     console.log("Class A");
            // }
     