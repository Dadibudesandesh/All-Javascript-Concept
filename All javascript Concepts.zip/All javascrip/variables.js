// V A R I A B L E S

    // types 
        // var
        // let
        // const

    // example

        // var name="sandesh";
        // let rollNo=10;
        // rollNo=104;    // update the value
        // const age=19;

        // const student ={
        //     name: "sandesh",
        //     rollno: 104,
        //     age: 19,
        //     cgpa: 9.15,
        //     isPass: true
        // };
        // student['name']="sandesh dadibude"; // update object variables data


        // console.log(rollNo);
        // console.log(name);
        // console.log(age);
        // console.log(student.name);
        // console.log(student['age']);






       
        


        


    

        


