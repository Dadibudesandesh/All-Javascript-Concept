// O P E R A T O R S

    // Arithmatic operator

        // let a=10;
        // console.log("A : "+a);
        // console.log(5+2);
        // console.log(3-6);
        // console.log(8+3);
        // console.log(7/2);
        // console.log(8%3);
        // console.log(8**2); //exponentiation operator
        // console.log("pre icreament operator : "+ ++a); 
        // console.log("post icreament operator : "+ a++,a);     
        // console.log("pre decriment operator : "+ --a); 
        // console.log("post decriment operator : "+ a--,a);

    // Assignment operators

        // let n=10;
        // console.log("n : "+n);
        // console.log("n+=10 : "+ (n+=10));
        // console.log("n-=10 : "+ (n-=10));
        // console.log("n*=10 : "+(n*=10));
        // console.log("n/=2 : "+(n/=2));
        // console.log("n%=2 : "+(n%=2));
        // console.log("n**=2 : "+(n **=2));

    // Comparison operators

        // console.log("2==2 : "+(2==2));
        // console.log("2==='2' : "+(2==="2"));
        // console.log("2!==2 : "+(2!==2));
        // console.log("2<=2 : "+(2<=2));
        // console.log("2>=3 : "+(2>=3));

    // Logical operators

        // console.log("cond1 : 2==2");
        // console.log("cond2 : 2>=2");
        // console.log("cond1 && cond2 : ", (2==2) && (2>=2));
        // console.log("cond1 || cond2 : ", (2==2) || (2>=2));
        // console.log("cond1 != cond2 : ", (2==2) != (2>=2));
        // console.log("cond1 >! cond2 : ", (2==2) >! (2>=2));
        // console.log("cond1 <! cond2 : ", (2==2) <! (2>=2));
